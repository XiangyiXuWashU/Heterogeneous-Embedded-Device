/*
 *  Do not modify this file; it is automatically 
 *  generated and any modifications will be overwritten.
 *
 * @(#) xdc-z57
 */

#ifndef miniloc__
#define miniloc__



#endif /* miniloc__ */ 
